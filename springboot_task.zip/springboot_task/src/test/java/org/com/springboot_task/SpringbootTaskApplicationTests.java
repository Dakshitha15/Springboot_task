package org.com.springboot_task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
