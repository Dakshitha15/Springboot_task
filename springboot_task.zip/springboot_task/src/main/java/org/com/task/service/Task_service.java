package org.com.task.service;

import java.util.Optional;

import org.com.task.dao.Task_Dao;
import org.com.task.dto.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Task_service {
	
	@Autowired
	private Task_Dao dao;
	
	
	//insert
	public void saveTask(Task task)
	{
		dao.saveTask(task);
	}
	
	//Get
    public Optional<Task> findById(String shipperId)
	{
		return dao.findById(shipperId);
	}
    
	//update
	public void updateTask(Task task)
	{
		 dao.updateTask(task);
		
	}
	
	//Delete
	public void deleteById(String shipperId)
	{
		dao.deleteById(shipperId);
	}

	
}
