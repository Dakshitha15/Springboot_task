package org.com.task.repository;

import org.com.task.dto.Task;
import org.springframework.data.jpa.repository.JpaRepository;


public interface Task_Repository extends JpaRepository<Task, String>{
	

}
