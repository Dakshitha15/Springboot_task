package org.com.task.controller;

import java.util.Optional;

import org.com.task.dto.Task;
import org.com.task.service.Task_service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Task_Controller {
	
	@Autowired
	private Task_service service;
	
	//save
	@PostMapping("/load")
	public void payload(@RequestBody Task task) {
		service.saveTask(task);
	}
	
	//Get
	@GetMapping("/load/{loadId}/")
	public Optional<Task> findById(@PathVariable String shipperId)
	{
		return service.findById(shipperId);
	
	}
	//update
	@PostMapping("/load/{loadId}/")
	public void updateTask(@RequestBody Task task)
	{
		Optional<Task> tasks=service.findById(task.getShipperId());
		tasks.get().setLoadingPoint(task.getLoadingPoint());
		service.saveTask(tasks.get());
		
	}
	
	//delete 
	@DeleteMapping("/load/{loadId}/")
	public void deleteById(@PathVariable String shipperId)
	{
		service.deleteById(shipperId);
	}
	
	

}
