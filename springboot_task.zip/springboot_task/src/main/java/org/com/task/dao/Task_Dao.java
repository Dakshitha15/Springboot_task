package org.com.task.dao;

import java.util.Optional;

import org.com.task.dto.Task;
import org.com.task.repository.Task_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.Entity;

@Repository
public class Task_Dao {
	
	@Autowired
	private Task_Repository repository;
	
	//insert
	public void saveTask(Task task)
	{
		repository.save(task);
	}
	
	//Get
	public Optional<Task> findById(String shipperId)
	{
		return repository.findById(shipperId);
	}
	
	//update
	public void updateTask(Task task)
	{
		 repository.save(task);
	}
	
	//delete
	public void deleteById(String shipperId)
	{
		repository.deleteById(shipperId);
	}


}
